import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
    request: NextRequest,
    context: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await context.params;
        const season = request.nextUrl.searchParams.get("season") || "2025";

        // Current season standing + driver info
        const currentStanding = await prisma.f1DriverStanding.findFirst({
            where: { driverId: id, season },
            include: {
                driver: true,
                constructor: true,
            },
        });

        if (!currentStanding) {
            // Try to find driver across any season
            const anyStanding = await prisma.f1DriverStanding.findFirst({
                where: { driverId: id },
                orderBy: { season: "desc" },
                include: { driver: true, constructor: true },
            });
            if (!anyStanding) {
                return NextResponse.json({ error: "Driver not found" }, { status: 404 });
            }
        }

        // Career history — all seasons this driver has standings data
        const careerStandings = await prisma.f1DriverStanding.findMany({
            where: { driverId: id },
            orderBy: { season: "desc" },
            include: { constructor: true },
        });

        // Podiums this season (position 1, 2, or 3) from race results
        const podiums = await prisma.f1RaceResult.count({
            where: {
                driverId: id,
                race: { season },
                position: { in: [1, 2, 3] },
            },
        });

        // Points finishes (points > 0) this season
        const pointsFinishes = await prisma.f1RaceResult.count({
            where: {
                driverId: id,
                race: { season },
                points: { gt: 0 },
            },
        });

        // DNFs this season
        const dnfs = await prisma.f1RaceResult.count({
            where: {
                driverId: id,
                race: { season },
                status: { not: "Finished" },
                positionText: { not: { in: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"] } },
            },
        });

        // Fastest laps this season
        const fastestLaps = await prisma.f1RaceResult.count({
            where: {
                driverId: id,
                race: { season },
                fastestLapRank: 1,
            },
        });

        // Teammate this season (same constructor, different driver)
        const teammateStanding = currentStanding
            ? await prisma.f1DriverStanding.findFirst({
                where: {
                    season,
                    constructorId: currentStanding.constructorId,
                    driverId: { not: id },
                },
                include: { driver: true },
            })
            : null;

        // Career totals
        const careerTotals = await prisma.f1RaceResult.aggregate({
            where: { driverId: id },
            _sum: { points: true },
            _count: { id: true },
        });

        const careerWins = await prisma.f1RaceResult.count({
            where: { driverId: id, position: 1 },
        });

        const careerPodiums = await prisma.f1RaceResult.count({
            where: { driverId: id, position: { in: [1, 2, 3] } },
        });

        const careerFastestLaps = await prisma.f1RaceResult.count({
            where: { driverId: id, fastestLapRank: 1 },
        });

        const championships = careerStandings.filter((s: { position: number }) => s.position === 1).length;

        const driver = currentStanding?.driver;
        const constructor = currentStanding?.constructor;

        return NextResponse.json({
            driver,
            constructor,
            currentStanding: currentStanding
                ? {
                    position: currentStanding.position,
                    points: currentStanding.points,
                    wins: currentStanding.wins,
                    season,
                }
                : null,
            seasonStats: {
                podiums,
                pointsFinishes,
                dnfs,
                fastestLaps,
            },
            careerHistory: careerStandings.map((s: { season: string; position: number; points: number; wins: number; constructorId: string; constructor: { name: string } | null }) => ({
                season: s.season,
                position: s.position,
                points: s.points,
                wins: s.wins,
                constructorId: s.constructorId,
                constructorName: s.constructor?.name ?? "",
            })),
            careerTotals: {
                races: careerTotals._count.id,
                points: careerTotals._sum.points ?? 0,
                wins: careerWins,
                podiums: careerPodiums,
                fastestLaps: careerFastestLaps,
                championships,
            },
            teammate: teammateStanding
                ? {
                    driverId: teammateStanding.driverId,
                    driver: teammateStanding.driver,
                    position: teammateStanding.position,
                    points: teammateStanding.points,
                    wins: teammateStanding.wins,
                }
                : null,
        });
    } catch (error) {
        console.error("Driver API error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}