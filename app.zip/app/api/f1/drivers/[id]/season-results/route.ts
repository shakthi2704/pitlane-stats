import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
    request: NextRequest,
    context: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await context.params;
        const season = request.nextUrl.searchParams.get("season") || "2025";

        const results = await prisma.raceResult.findMany({
            where: {
                driverId: id,
                race: { season },
            },
            orderBy: {
                race: { round: "asc" },
            },
            include: {
                race: {
                    include: {
                        circuit: true,
                    },
                },
                constructor: true,
            },
        });

        // Teammate results for same races (H2H)
        const constructorIds = [...new Set(results.map((r) => r.constructorId))];

        const teammateResults = await prisma.raceResult.findMany({
            where: {
                driverId: { not: id },
                constructorId: { in: constructorIds },
                race: { season },
            },
            include: {
                driver: true,
                race: true,
            },
        });

        // Build H2H map: raceRound → { driver: pos, teammate: pos }
        const h2hMap: Record<
            number,
            { driverPos: number | null; teammatePos: number | null; teammateId: string; teammateName: string }
        > = {};

        for (const r of results) {
            h2hMap[r.race.round] = {
                driverPos: r.position,
                teammatePos: null,
                teammateId: "",
                teammateName: "",
            };
        }

        for (const tr of teammateResults) {
            const round = tr.race.round;
            if (h2hMap[round]) {
                h2hMap[round].teammatePos = tr.position;
                h2hMap[round].teammateId = tr.driverId;
                h2hMap[round].teammateName = `${tr.driver.givenName} ${tr.driver.familyName}`;
            }
        }

        const formattedResults = results.map((r) => ({
            round: r.race.round,
            raceName: r.race.raceName,
            circuit: r.race.circuit?.circuitName ?? "",
            country: r.race.circuit?.country ?? "",
            date: r.race.date,
            position: r.position,
            positionText: r.positionText,
            grid: r.grid,
            points: r.points,
            laps: r.laps,
            status: r.status,
            time: r.time,
            fastestLapTime: r.fastestLapTime,
            fastestLapRank: r.fastestLapRank,
            constructorId: r.constructorId,
            constructorName: r.constructor?.name ?? "",
            h2h: h2hMap[r.race.round] ?? null,
        }));

        return NextResponse.json({ results: formattedResults });
    } catch (error) {
        console.error("Driver season results error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}